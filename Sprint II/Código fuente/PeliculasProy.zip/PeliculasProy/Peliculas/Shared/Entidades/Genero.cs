using System;
namespace Peliculas.Shared.Entidades
{
    public enum Genero
    {
        Accion,
        Aventura,
        CienciaFiccion,
        Comedia,
        Documental,
        Drama,
        Fantasia,
        Musical,
        Suspenso,
        Terror,
        Otro
    }
}