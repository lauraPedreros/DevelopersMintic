using System;
namespace Peliculas.Shared.Entidades
{
    public enum TipoDocumento
    {
        RegistroCivil,
        TarjetaIdentidad,
        CedulaCiudadania,
        CedulaExtranjera,
        Pasaporte,
        Otro
    }
}