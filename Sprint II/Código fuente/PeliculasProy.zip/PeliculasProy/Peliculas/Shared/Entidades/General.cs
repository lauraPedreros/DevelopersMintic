using System;
namespace Peliculas.Shared.Entidades
{
    public class General
    {
        public int Id {get;set;}
        public string Nombre {get;set;}
    }
}