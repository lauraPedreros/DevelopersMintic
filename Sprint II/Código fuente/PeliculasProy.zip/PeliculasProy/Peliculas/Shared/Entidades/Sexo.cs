using System;
namespace Peliculas.Shared.Entidades
{
    public enum Sexo
    {
        Masculino,
        Femenino,
        Bisexual,
        Intersexual,
        Pansexual,
        Transexual
    }
}